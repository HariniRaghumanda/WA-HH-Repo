package com.example.Spring_WhatsappDTO;


public class UserDTO {
    private String username;
    private String status;

    // Constructors
    public UserDTO() {}
    
    public UserDTO(String username, String status) {
        this.username = username;
        this.status = status;
    }

    // Getters & Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

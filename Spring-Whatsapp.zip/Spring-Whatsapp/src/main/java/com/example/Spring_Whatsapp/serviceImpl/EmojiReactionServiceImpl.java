package com.example.Spring_Whatsapp.serviceImpl;

import com.example.Spring_Whatsapp.entity.*;
import com.example.Spring_Whatsapp.repository.*;
import com.example.Spring_Whatsapp.service.EmojiReactionService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Set;

@Service
public class EmojiReactionServiceImpl implements EmojiReactionService {

	private static final Set<String> VALID_EMOJIS = Set.of("❤️", "😂", "👍", "😢", "🎉", "🔥", "😍", "🙏", "🤔");

    @Autowired
    private EmojiReactionRepository emojiReactionRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public EmojiReaction reactToMessage(Long messageId, Long userId, String emoji) {
        if (!VALID_EMOJIS.contains(emoji)) {
            throw new IllegalArgumentException("Invalid emoji: " + emoji);
        }

        Message message = messageRepository.findById(messageId)
                .orElseThrow(() -> new RuntimeException("Message not found"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        EmojiReaction reaction = emojiReactionRepository
                .findByMessageIdAndUserId(messageId, userId)
                .orElse(new EmojiReaction());

        reaction.setEmoji(emoji);
        reaction.setMessage(message);
        reaction.setUser(user);

        return emojiReactionRepository.save(reaction);
    }
}

package com.example.Spring_Whatsapp.service;

import com.example.Spring_Whatsapp.entity.EmojiReaction;

public interface EmojiReactionService {
    EmojiReaction reactToMessage(Long messageId, Long userId, String emoji);
}

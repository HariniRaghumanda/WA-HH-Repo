package com.example.Spring_Whatsapp.serviceImpl;

import com.example.Spring_Whatsapp.entity.User;
import com.example.Spring_Whatsapp.repository.UserRepository;
import com.example.Spring_Whatsapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User createUser(User userDto) {
        // Map DTO to Entity
        User user = new User();
        user.setUsername(userDto.getUsername());
        user.setStatus(userDto.getStatus());

        return userRepository.save(user);
    }
    @Override
    public User updateUser(Long id, User updatedUser) {
        User existingUser = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found with ID: " + id));

        existingUser.setUsername(updatedUser.getUsername());
        existingUser.setStatus(updatedUser.getStatus());

        return userRepository.save(existingUser);
    }


    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }

	@Override
	public void deleteUser(Long id) {
		// TODO Auto-generated method stub
		
	}
}

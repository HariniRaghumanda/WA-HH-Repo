package com.example.Spring_Whatsapp.service;

import com.example.Spring_Whatsapp.entity.Message;

import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;



public interface MessageService {
    Message sendMessage(Message message);
    Page<Message> getMessagesByChatRoomId(Long chatRoomId, int page, int size);
    Message getMessageById(Long id);
	Message sendMessage(Long chatroomId, Long userId, String content, String attachment);
	ResponseEntity<Resource> downloadAttachment(Long messageId);
	Message sendMessage(Long chatroomId, Long userId, String content, MultipartFile attachment);
	

}

package com.example.Spring_Whatsapp.service;

import com.example.Spring_Whatsapp.entity.User;
import java.util.List;

public interface UserService {
	User updateUser(Long id, User updatedUser);
    User createUser(User userDto);
    List<User> getAllUsers();
    User getUserById(Long id);
    void deleteUserById(Long id);
	void deleteUser(Long id);
}
package com.example.Spring_Whatsapp.serviceImpl;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import com.example.Spring_Whatsapp.entity.User;
import com.example.Spring_Whatsapp.repository.ChatRoomRepository;
import com.example.Spring_Whatsapp.repository.UserRepository;
import com.example.Spring_Whatsapp.service.ChatRoomService;
import com.example.Spring_WhatsappDTO.ChatroomRequestDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class ChatRoomServiceImpl implements ChatRoomService {

    @Autowired
    private ChatRoomRepository chatRoomRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public ChatRoom createChatRoom(ChatroomRequestDTO chatroomRequestDTO) {
        User creator = userRepository.findById(chatroomRequestDTO.getCreatedByUserId())
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + chatroomRequestDTO.getCreatedByUserId()));

        ChatRoom chatRoom = new ChatRoom();
        chatRoom.setName(chatroomRequestDTO.getName());
        chatRoom.setParticipants(Collections.singletonList(creator));

        return chatRoomRepository.save(chatRoom);
    }

    @Override
    public List<ChatRoom> getAllChatRooms() {
        return chatRoomRepository.findAll();
    }

    @Override
    public ChatRoom getChatRoomById(Long id) {
        return chatRoomRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteChatRoom(Long id) {
        chatRoomRepository.deleteById(id);
    }
}

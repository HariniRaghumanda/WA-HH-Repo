package com.example.Spring_Whatsapp.serviceImpl;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import com.example.Spring_Whatsapp.entity.Message;
import com.example.Spring_Whatsapp.entity.User;
import com.example.Spring_Whatsapp.repository.ChatRoomRepository;
import com.example.Spring_Whatsapp.repository.MessageRepository;
import com.example.Spring_Whatsapp.repository.UserRepository;
import com.example.Spring_Whatsapp.service.MessageService;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Service
public class MessageServiceImpl implements MessageService {

    private static final String BASE_DIR = "uploads/";
    private static final String PICTURE_DIR = BASE_DIR + "picture/";
    private static final String VIDEO_DIR = BASE_DIR + "video/";

    @PostConstruct
    public void initFolders() {
        new File(PICTURE_DIR).mkdirs();
        new File(VIDEO_DIR).mkdirs();
    }

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private ChatRoomRepository chatroomRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Message getMessageById(Long id) {
        return messageRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Message not found with id: " + id));
    }

    @Override
    public Message sendMessage(Long chatroomId, Long userId, String content, MultipartFile attachment) {
        ChatRoom chatroom = chatroomRepository.findById(chatroomId)
                .orElseThrow(() -> new RuntimeException("Chatroom not found"));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Message message = new Message();
        message.setChatroom(chatroom);
        message.setUser(user);
        message.setContent(content);

        if (attachment != null && !attachment.isEmpty()) {
            try {
                String fileName = UUID.randomUUID() + "_" + attachment.getOriginalFilename();
                String contentType = attachment.getContentType();
                String folder;

                if (contentType != null && contentType.startsWith("image/")) {
                    folder = PICTURE_DIR;
                } else if (contentType != null && contentType.startsWith("video/")) {
                    folder = VIDEO_DIR;
                } else {
                    throw new RuntimeException("Unsupported file type: " + contentType);
                }

                File uploadPath = new File(folder);
                if (!uploadPath.exists()) uploadPath.mkdirs();

                Path filePath = Paths.get(folder + fileName);
                Files.copy(attachment.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                message.setAttachment(filePath.toString()); // full path or relative path
            } catch (IOException e) {
                throw new RuntimeException("Failed to save attachment", e);
            }
        }

        return messageRepository.save(message);
    }

    @Override
    public ResponseEntity<Resource> downloadAttachment(Long messageId) {
        Message message = messageRepository.findById(messageId)
                .orElseThrow(() -> new RuntimeException("Message not found with id: " + messageId));

        String filePath = message.getAttachmentPath();
        if (filePath == null || filePath.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        File file = new File(filePath);
        if (!file.exists()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        Resource resource = new FileSystemResource(file);
        String contentType = determineContentType(filePath);

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
                .body(resource);
    }

    private String determineContentType(String filePath) {
        if (filePath.endsWith(".png")) return "image/png";
        if (filePath.endsWith(".jpg") || filePath.endsWith(".jpeg")) return "image/jpeg";
        if (filePath.endsWith(".webp")) return "image/webp";
        if (filePath.endsWith(".mp4")) return "video/mp4";
        return "application/octet-stream";
    }

    // These are unused and returning null — remove if not needed
    @Override
    public Page<Message> getMessagesByChatRoomId(Long chatRoomId, int page, int size) {
        return null;
    }

    @Override
    public Message sendMessage(Long chatroomId, Long userId, String content, String attachment) {
        return null;
    }

    @Override
    public Message sendMessage(Message message) {
        return null;
    }
}

package com.example.Spring_Whatsapp.repository;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatRoomRepository extends JpaRepository<ChatRoom, Long> {}

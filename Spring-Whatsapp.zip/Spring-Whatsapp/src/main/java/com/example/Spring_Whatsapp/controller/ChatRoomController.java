package com.example.Spring_Whatsapp.controller;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import com.example.Spring_Whatsapp.service.ChatRoomService;
import com.example.Spring_WhatsappDTO.ChatroomRequestDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chatrooms")
public class ChatRoomController {

    @Autowired
    private ChatRoomService chatRoomService;

    // ✅ Use only this POST method
    @PostMapping
    public ResponseEntity<ChatRoom> createChatroom(@RequestBody ChatroomRequestDTO chatroomRequestDTO) {
        ChatRoom createdChatRoom = chatRoomService.createChatRoom(chatroomRequestDTO);
        return ResponseEntity.ok(createdChatRoom);
    }

    @GetMapping
    public List<ChatRoom> getAllChatRooms() {
        return chatRoomService.getAllChatRooms();
    }

    @GetMapping("/{id}")
    public ChatRoom getChatRoom(@PathVariable Long id) {
        return chatRoomService.getChatRoomById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteChatRoom(@PathVariable Long id) {
        chatRoomService.deleteChatRoom(id);
    }
}

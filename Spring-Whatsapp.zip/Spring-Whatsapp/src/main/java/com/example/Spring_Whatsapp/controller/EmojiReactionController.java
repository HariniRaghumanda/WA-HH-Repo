package com.example.Spring_Whatsapp.controller;

import com.example.Spring_Whatsapp.entity.EmojiReaction;
import com.example.Spring_Whatsapp.service.EmojiReactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reactions")
public class EmojiReactionController {

    @Autowired
    private EmojiReactionService emojiReactionService;

    @PostMapping("/react")
    public EmojiReaction reactToMessage(
            @RequestParam Long messageId,
            @RequestParam Long userId,
            @RequestParam String emoji
    ) {
        return emojiReactionService.reactToMessage(messageId, userId, emoji);
    }
}

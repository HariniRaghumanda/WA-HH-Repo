package com.example.Spring_Whatsapp.controller;

import com.example.Spring_Whatsapp.entity.Message;
import com.example.Spring_Whatsapp.service.MessageService;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageService messageService;

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Message> sendMessage(
            @Parameter(description = "Chatroom ID") @RequestParam Long chatroomId,
            @Parameter(description = "User ID") @RequestParam Long userId,
            @Parameter(description = "Message content") @RequestParam String content,
            @Parameter(description = "Attachment file (optional)") @RequestPart(required = false) MultipartFile attachment
    ) throws IOException {
        Message savedMessage = messageService.sendMessage(chatroomId, userId, content, attachment);
        return new ResponseEntity<>(savedMessage, HttpStatus.CREATED);
    }

    @Operation(summary = "Download attachment (image/video) for a message")
    @GetMapping("/{id}/attachment")
    public ResponseEntity<Resource> downloadAttachment(@PathVariable Long id, HttpServletRequest request) throws IOException {
        return messageService.downloadAttachment(id);
    }
}

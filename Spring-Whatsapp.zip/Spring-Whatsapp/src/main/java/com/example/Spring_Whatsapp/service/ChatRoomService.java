package com.example.Spring_Whatsapp.service;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import com.example.Spring_WhatsappDTO.ChatroomRequestDTO;

import java.util.List;

public interface ChatRoomService {
    ChatRoom createChatRoom(ChatroomRequestDTO chatroomRequestDTO);
    List<ChatRoom> getAllChatRooms();
    ChatRoom getChatRoomById(Long id);
    void deleteChatRoom(Long id);
}

package com.example.Spring_Whatsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication 
@ComponentScan(basePackages = "com.example.Spring_Whatsapp")
public class WhatsappApplication {
    public static void main(String[] args) {
        SpringApplication.run(WhatsappApplication.class, args);
    }
}


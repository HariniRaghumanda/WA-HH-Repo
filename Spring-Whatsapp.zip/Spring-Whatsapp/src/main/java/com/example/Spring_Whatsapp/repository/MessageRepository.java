package com.example.Spring_Whatsapp.repository;

import com.example.Spring_Whatsapp.entity.ChatRoom;
import com.example.Spring_Whatsapp.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
	Page<Message> findByChatRoom(ChatRoom chatRoom, Pageable pageable);
}

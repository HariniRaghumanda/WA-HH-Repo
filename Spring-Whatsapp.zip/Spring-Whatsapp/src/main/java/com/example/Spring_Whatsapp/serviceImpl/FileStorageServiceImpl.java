package com.example.Spring_Whatsapp.serviceImpl;



import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.Spring_Whatsapp.service.FileStorageService;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class FileStorageServiceImpl implements FileStorageService {

    private final String UPLOAD_DIR = "uploads/";

    public String saveFile(MultipartFile file) {
        try {
            File dir = new File(UPLOAD_DIR);
            if (!dir.exists()) dir.mkdirs();

            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
            File dest = new File(dir, fileName);
            file.transferTo(dest);

            return dest.getAbsolutePath();
        } catch (IOException e) {
            throw new RuntimeException("File upload failed", e);
        }
    }
}

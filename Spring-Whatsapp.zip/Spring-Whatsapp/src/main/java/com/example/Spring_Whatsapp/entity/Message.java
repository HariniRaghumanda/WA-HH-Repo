package com.example.Spring_Whatsapp.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Message {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String content;

    private String attachmentPath;

    private LocalDateTime timestamp;

    @ManyToOne
    @JoinColumn(name = "chatroom_id")
    private ChatRoom chatRoom;
    @ManyToOne
    @JoinColumn(name = "sender_id")
    private User sender;

    // Getters and Setters

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getContent() { return content; }

    public void setContent(String content) { this.content = content; }

    public String getAttachmentPath() { return attachmentPath; }

    public void setAttachmentPath(String attachmentPath) { this.attachmentPath = attachmentPath; }

    public LocalDateTime getTimestamp() { return timestamp; }

    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public ChatRoom getChatroom() { return chatRoom; }

    public void setChatroom(ChatRoom chatroom) { this.chatRoom = chatroom; }

    public User getSender() { return sender; }

    public void setSender(User sender) { this.sender = sender; }

	public void setUser(User user) {
		// TODO Auto-generated method stub
		
	}

	public void setAttachment(String attachment) {
		// TODO Auto-generated method stub
		
	}
}

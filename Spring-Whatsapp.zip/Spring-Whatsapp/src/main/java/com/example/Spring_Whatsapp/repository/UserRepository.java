package com.example.Spring_Whatsapp.repository;

import com.example.Spring_Whatsapp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {}

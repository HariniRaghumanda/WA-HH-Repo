package com.example.Spring_Whatsapp.service;


import org.springframework.web.multipart.MultipartFile;

public interface FileStorageService {
    static String saveFile(MultipartFile file) {
		// TODO Auto-generated method stub
		return null;
	}
}
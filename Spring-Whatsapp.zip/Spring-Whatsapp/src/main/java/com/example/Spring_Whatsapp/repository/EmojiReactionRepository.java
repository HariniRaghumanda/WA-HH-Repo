package com.example.Spring_Whatsapp.repository;

import com.example.Spring_Whatsapp.entity.EmojiReaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmojiReactionRepository extends JpaRepository<EmojiReaction, Long> {
    Optional<EmojiReaction> findByMessageIdAndUserId(Long messageId, Long userId);
}

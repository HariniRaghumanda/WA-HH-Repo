package com.example.Spring_Whatsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWhatsappApplicationTests {

	@Test
	void contextLoads() {
	}

}
